package ie.gmit.sw;

public class Runner {
	public static void main(String[] args) {
		/**
		 * Main method runs the instance of the class Results and method go().
		 */
		new Results().go();
	}
}
